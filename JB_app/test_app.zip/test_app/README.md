# Flask App Template for Insight
Run with ./run.py
