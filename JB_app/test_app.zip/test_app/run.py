#! /usr/bin/env python
from flaskexample import app
app.run(host='0.0.0.0', debug=True)
