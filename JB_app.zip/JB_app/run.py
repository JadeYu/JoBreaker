#!/usr/bin/env python
from flaskexample import app
app.run(debug = True)
